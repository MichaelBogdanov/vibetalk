from django.shortcuts import render
from .forms import MessagesForm

# Create your views here.
def index(request):
    data = {
        'form': MessagesForm()
    }
    return render(request, 'index.html', data)