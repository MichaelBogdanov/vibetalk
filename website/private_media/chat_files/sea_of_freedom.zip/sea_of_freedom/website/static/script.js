// Получаем элемент корабля
const boat = document.getElementById('boat');
const body = document.body;

// Параметры корабля
let mouseX = 0;
let mouseY = 0;
let boatX = 0;
let boatY = 0;
let isMouseDown = false;
const MAX_SPEED = 2.5; // Увеличим максимальную скорость
const ACCELERATION = 0.04; // Увеличим ускорение
const ROTATION_SPEED = 0.12; // Скорость поворота

// Векторы движения
let velocityX = 0;
let velocityY = 0;
let currentAngle = 0;
let animationId = null;

// Коэффициенты сопротивления
const FORWARD_DECEL = 0.98;    // Сопротивление при движении вперед (слабое)
const SIDEWAYS_DECEL = 0.85;   // Сопротивление при боковом движении (сильное)

// Инициализация позиции корабля
function initBoatPosition() {
    boatX = body.offsetWidth / 2;
    boatY = body.offsetHeight / 2;

    // Устанавливаем начальные стили
    boat.style.position = 'absolute';
    boat.style.transformOrigin = 'center';
    boat.style.transform = 'rotate(0deg)'; // Начальный поворот вправо
    
    // Центрируем корабль
    const rect = boat.getBoundingClientRect();
    boatX -= rect.width / 2;
    boatY -= rect.height / 2;
    boat.style.left = `${boatX}px`;
    boat.style.top = `${boatY}px`;
    
    // Сбрасываем скорость
    velocityX = 0;
    velocityY = 0;

    // Скроллим до корабля
    boat.scrollIntoView({ block: 'center', inline: 'center' })
}

// Вычисление угла между кораблем и курсором
function calculateAngle(targetX, targetY, sourceX, sourceY) {
    const dx = targetX - sourceX;
    const dy = targetY - sourceY;
    return Math.atan2(dy, dx) * (180 / Math.PI);
}

// Применяем гидродинамическое сопротивление
function applyHydrodynamics() {
    // Разлагаем скорость на компоненты относительно направления корабля
    const angleRad = currentAngle * (Math.PI / 180);
    const cosA = Math.cos(angleRad);
    const sinA = Math.sin(angleRad);
    
    // Проекции скорости на направление носа (вперед/назад) и боковое направление
    const forwardSpeed = velocityX * cosA + velocityY * sinA;
    const sideSpeed = -velocityX * sinA + velocityY * cosA;
    
    // Применяем разные коэффициенты затухания
    const newForwardSpeed = forwardSpeed * FORWARD_DECEL;
    const newSideSpeed = sideSpeed * SIDEWAYS_DECEL; // Боковое движение быстро затухает
    
    // Преобразуем обратно в глобальные координаты
    velocityX = newForwardSpeed * cosA - newSideSpeed * sinA;
    velocityY = newForwardSpeed * sinA + newSideSpeed * cosA;
    
    // Если скорость очень мала, останавливаем полностью
    const currentSpeed = Math.sqrt(velocityX * velocityX + velocityY * velocityY);
    if (currentSpeed < 0.01) {
        velocityX = 0;
        velocityY = 0;
    }
}

// Плавное движение и поворот
function animateBoat() {
    // Если кнопка мыши нажата - управляем кораблем
    if (isMouseDown) {
        // Текущие координаты центра корабля
        const rect = boat.getBoundingClientRect();
        const boatCenterX = boatX + rect.width / 2;
        const boatCenterY = boatY + rect.height / 2;
        
        // Вычисляем целевой угол
        const targetAngle = calculateAngle(mouseX, mouseY, boatCenterX, boatCenterY);
        
        // Плавный поворот
        let angleDiff = targetAngle - currentAngle;
        // Нормализуем угол к кратчайшему пути
        while (angleDiff > 180) angleDiff -= 360;
        while (angleDiff < -180) angleDiff += 360;
        
        currentAngle += angleDiff * ROTATION_SPEED;
        
        // Ускоряем корабль в направлении носа
        const angleRad = currentAngle * (Math.PI / 180);
        
        // Добавляем ускорение
        velocityX += Math.cos(angleRad) * ACCELERATION;
        velocityY += Math.sin(angleRad) * ACCELERATION;
        
        // Ограничиваем максимальную скорость
        const currentSpeed = Math.sqrt(velocityX * velocityX + velocityY * velocityY);
        if (currentSpeed > MAX_SPEED) {
            velocityX = (velocityX / currentSpeed) * MAX_SPEED;
            velocityY = (velocityY / currentSpeed) * MAX_SPEED;
        }
    }
    
    // Всегда применяем гидродинамику (даже при управлении)
    applyHydrodynamics();
    
    // Обновляем позицию корабля
    boatX += velocityX;
    boatY += velocityY;

    // Скроллим до корабля
    boat.scrollIntoView({ block: 'center', inline: 'center' })
    
    // Проверяем границы экрана
    const rect = boat.getBoundingClientRect();
    const margin = 20;
    
    if (boatX < -rect.width + margin) {
        boatX = -rect.width + margin;
        velocityX = Math.abs(velocityX) * 0.5;
    }
    if (boatX > body.offsetWidth - margin) {
        boatX = body.offsetWidth - margin;
        velocityX = -Math.abs(velocityX) * 0.5;
    }
    if (boatY < -rect.height + margin) {
        boatY = -rect.height + margin;
        velocityY = Math.abs(velocityY) * 0.5;
    }
    if (boatY > body.offsetHeight - margin) {
        boatY = body.offsetHeight - margin;
        velocityY = -Math.abs(velocityY) * 0.5;
    }
    
    // Обновляем позицию и поворот корабля
    boat.style.left = `${boatX}px`;
    boat.style.top = `${boatY}px`;
    boat.style.transform = `rotate(${currentAngle}deg)`;
    
    // Продолжаем анимацию
    animationId = requestAnimationFrame(animateBoat);
}

// Обработчики событий
body.addEventListener('mousedown', (e) => {
    if (e.button === 0) {
        isMouseDown = true;
        mouseX = e.offsetX;
        mouseY = e.offsetY;
        
        // Запускаем анимацию
        if (!animationId) {
            animationId = requestAnimationFrame(animateBoat);
        }
    }
});

body.addEventListener('mousemove', (e) => {
    mouseX = e.offsetX;
    mouseY = e.offsetY;
});

body.addEventListener('mouseup', (e) => {
    if (e.button === 0) {
        isMouseDown = false;
    }
});

body.addEventListener('mouseleave', () => {
    isMouseDown = false;
});

// Инициализация
window.addEventListener('DOMContentLoaded', initBoatPosition);
window.addEventListener('resize', initBoatPosition);

// Отключение контекстного меню
body.addEventListener('contextmenu', (e) => e.preventDefault());

// Послание
boat.addEventListener('click', function() {
    Fancybox.show([{ src: "#message_form", type: "inline" }]);
});