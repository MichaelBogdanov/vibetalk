from django.db import models

# Create your models here.
class Messages(models.Model):
    text = models.CharField('Текст послания', max_length=3000)
    x = models.FloatField('Координата X')
    y = models.FloatField('Координата Y')
    
    def __str__(self):
        return self.text
    
    class Meta:
        verbose_name = 'послание'
        verbose_name_plural = 'Послания'